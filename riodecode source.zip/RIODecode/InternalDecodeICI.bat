echo --- Decoding A017KDS.rio.ici file
md OriginalICI
del OriginalICI\*.
RIODecode.exe ..\a017kds.rio.ici OriginalICI\ b29d5a0c

echo --- Removing second level encode
md OriginalICIDecoded
cd OriginalICI
for %%a in (*.) do ..\ICIDecode.exe %%a ..\OriginalICIDecoded\%%a
cd ..

md ModifiedICIDecoded
del ModifiedICIDecoded\*.
copy OriginalICIDecoded\*. ModifiedICIDecoded\