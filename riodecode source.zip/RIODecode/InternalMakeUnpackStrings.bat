echo --- Unpacking original strings to Strings folder
md Strings
del Strings\*.
cd OriginalGOs
for %%a in (*.) do ..\UnpackGOStrings %%a ..\Strings\%%a
cd ..
