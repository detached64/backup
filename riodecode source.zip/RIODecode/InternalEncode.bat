echo --- Encoding GOs into RIO file...
cd ModifiedGOs
for %%a in (*.) do ..\RIOEncode %%a ..\..\a017kds.rio 7e6b8ce2 %%a
cd ..