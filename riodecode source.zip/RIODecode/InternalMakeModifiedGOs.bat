echo --- Making modified GOs, putting them into ModifiedGOs folder
md ModifiedGOs
del ModifiedGOs\*.
copy PremodifiedGOs\*. ModifiedGOs\
PatchPointersAuto OriginalGOs\ newPointers ModifiedGOs\ ..\a017KDS.rio 8000000