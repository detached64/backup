echo --- Making Pre-modified game objects, putting them into PremodifiedGOs folder
md PremodifiedGOs
del PremodifiedGOs\*.
copy OriginalGOs\*. PremodifiedGOs\
cd Strings
for %%a in (*.) do ..\PatchGOStrings.exe ..\OriginalGOs\%%a %%a ..\PremodifiedGOs\%%a
cd ..
