echo --- Rolling second-level encoding back
md ModifiedICI
del ModifiedICI\*.
cd ModifiedICIDecoded
for %%a in (*.) do ..\ICIEncode %%a ..\ModifiedICI\%%a

echo --- Updating A017KDS.rio.ici file
cd ..\ModifiedICI
for %%a in (*.) do ..\RIOEncode %%a ..\..\a017kds.rio.ici b29d5a0c %%a
cd ..
