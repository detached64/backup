echo --- Unpacking original game objects to OriginalGOs folder
md OriginalGOs
del OriginalGOs\*.
RIODecode.exe ..\Alternative.rio OriginalGOs\ 7e6b8ce2 0

call InternalMakeUnpackStrings.bat