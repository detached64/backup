call InternalMakePMGOs.bat
call InternalMakeModifiedGOs.bat
call InternalEncode.bat

copy A017KDS.rio.ici ..\A017KDS.rio.ici