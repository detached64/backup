echo --- Unpacking strings from objects that need tweaked parameters

UnpackGOStrings.exe OriginalGOs\0000507076 Strings\0000507076 4
UnpackGOStrings.exe OriginalGOs\0000546889 strings\0000546889 4
UnpackGOStrings.exe OriginalGOs\0000655296 Strings\0000655296 3
UnpackGOStrings.exe OriginalGOs\0000709082 Strings\0000709082 5 500 100
UnpackGOStrings.exe OriginalGOs\0000853631 Strings\0000853631 5 500 50 20 90
UnpackGOStrings.exe OriginalGOs\0000865407 Strings\0000865407 3
UnpackGOStrings.exe OriginalGOs\0001093523 Strings\0001093523 5 500 20
UnpackGOStrings.exe OriginalGOs\0001162012 Strings\0001162012 5 500 30
UnpackGOStrings.exe OriginalGOs\0001991840 Strings\0001991840 4
UnpackGOStrings.exe OriginalGOs\0002115136 Strings\0002115136 5 500 100
UnpackGOStrings.exe OriginalGOs\0002886360 Strings\0002886360 5 500 300
UnpackGOStrings.exe OriginalGOs\0002886360 Strings\0002886360 5 500 300
UnpackGOStrings.exe OriginalGOs\0003055880 Strings\0003055880 5 500 50 20 50
UnpackGOStrings.exe OriginalGOs\0003140592 Strings\0003140592 5 500 12
UnpackGOStrings.exe OriginalGOs\0003166295 Strings\0003166295 5 500 50 20 50
UnpackGOStrings.exe OriginalGOs\0003166295 Strings\0003166295 5 500 50 20 50
UnpackGOStrings.exe OriginalGOs\0003470832 Strings\0003470832 5 500 50 20 50
UnpackGOStrings.exe OriginalGOs\0003601607 Strings\0003601607 3
UnpackGOStrings.exe OriginalGOs\0003658383 Strings\0003658383 5 300
UnpackGOStrings.exe OriginalGOs\0003803451 Strings\0003803451 5 500 50 20 50
UnpackGOStrings.exe OriginalGOs\0003916268 Strings\0003916268 5 500 20
UnpackGOStrings.exe OriginalGOs\0003985148 Strings\0003985148 5 500 20
UnpackGOStrings.exe OriginalGOs\0004038425 Strings\0004038425 5 500 20
UnpackGOStrings.exe OriginalGOs\0004097819 Strings\0004097819 5 300 50
UnpackGOStrings.exe OriginalGOs\0004187177 Strings\0004187177 2
UnpackGOStrings.exe OriginalGOs\0004254394 Strings\0004254394 4
UnpackGOStrings.exe OriginalGOs\0004337191 Strings\0004337191 5 500 50 20 50
UnpackGOStrings.exe OriginalGOs\0004374119 Strings\0004374119 5 300
UnpackGOStrings.exe OriginalGOs\0004527943 Strings\0004527943 5 300
UnpackGOStrings.exe OriginalGOs\0004566469 Strings\0004566469 5 300
UnpackGOStrings.exe OriginalGOs\0004580754 Strings\0004580754 5 500 100
UnpackGOStrings.exe OriginalGOs\0004711300 Strings\0004711300 5 500 50 20 50
UnpackGOStrings.exe OriginalGOs\0004719283 Strings\0004719283 5 500 100
UnpackGOStrings.exe OriginalGOs\0004751633 Strings\0004751633 5 300
UnpackGOStrings.exe OriginalGOs\0004899002 Strings\0004899002 3
