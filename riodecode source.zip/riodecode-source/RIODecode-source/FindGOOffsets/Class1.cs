using System;
using System.IO;

namespace FindGOOffsets
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Parameters
			if (args.Length < 1)
			{
				Console.WriteLine("Usage: FindGOOffsets game_object");
				return;
			}

			string inputFileName = args[0];
			#endregion

			using (FileStream inputStream = new FileStream(inputFileName, FileMode.Open, FileAccess.Read))
			using (BinaryReader inputReader = new BinaryReader(inputStream))
			{
				int curNumber = 1;
				uint curOffset = 0;
				
				for (int position = 2; position < inputStream.Length-6;)
				{
					inputStream.Seek(position, SeekOrigin.Begin);
					UInt32 current = inputReader.ReadUInt32();

					if ((current & (~0x0F)) == curNumber << 16)
					{
						inputStream.Seek(position-2, SeekOrigin.Begin);
						UInt32 offset = inputReader.ReadUInt32();
						if (offset > curOffset)
						{
							Console.WriteLine("Object {0}, offset {1};", curNumber, offset);

							inputStream.Seek(position+4, SeekOrigin.Begin);
							curNumber++;
							position +=4;
							curOffset = offset;
							continue;
						}
					}

					position++;
				}
			}
			Console.ReadLine();
		}
	}
}
