using System;
using System.IO;

namespace PatchPointers
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Parameters
			if (args.Length < 4)
			{
				Console.WriteLine("Usage: PatchPointers pointers_file changed_file new_offset destination_file");
				return;
			}

			string pointersFileName = args[0];
			string changedFileName = args[1];
			int newOffset = Int32.Parse(args[2], System.Globalization.NumberStyles.Integer);
			string destinationFileName = args[3];
			#endregion

			int newSize = (int)new FileInfo(changedFileName).Length;

			using (StreamReader pointersReader = new StreamReader(pointersFileName))
			using (FileStream destStream = new FileStream(destinationFileName, FileMode.Open, FileAccess.Write))
			using (BinaryWriter destWriter = new BinaryWriter(destStream))
			{
				string pointerString;
				while((pointerString = pointersReader.ReadLine()) != null)
				{
					int destinationOffset = Int32.Parse(pointerString, System.Globalization.NumberStyles.Integer);
					destWriter.Seek(destinationOffset, SeekOrigin.Begin);

					destWriter.Write(RIO.General.EncodeGOOffset((uint)newOffset-12));
					destWriter.Write(RIO.General.EncodeGOFileSize((uint)newSize));
				}
			}					   
		}
	}
}
