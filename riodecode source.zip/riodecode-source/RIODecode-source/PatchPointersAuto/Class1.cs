using System;
using System.IO;

namespace PatchPointersAuto
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		struct Pointer
		{
			public int headerOffset;
			public UInt64 pointer;
			public byte[] header;
			public string currentFileName;
			public string newFileName;
		};

		static void PatchFile(string fileName, System.Collections.Hashtable pointers, int lengthToUpdate)
		{
			using (FileStream patchStream = new FileStream(fileName, FileMode.Open, FileAccess.ReadWrite))
			using (BinaryReader patchReader = new BinaryReader(patchStream))
			using (BinaryWriter patchWriter = new BinaryWriter(patchStream))
			{
				UInt64 currentPointer = patchReader.ReadUInt64();

				for (int current = 0; current < patchStream.Length-8;)
				{
					if (lengthToUpdate > 0 && current > lengthToUpdate)
						break;

					if (pointers.ContainsKey(currentPointer))
					{
						Console.WriteLine("Found at offset {0:d10}, patched.", current);
						patchWriter.Seek(current, SeekOrigin.Begin);
						patchWriter.Write(((Pointer)pointers[currentPointer]).pointer);
						currentPointer = patchReader.ReadUInt64();
						current += 8;
					}
					else
					{
						currentPointer = (currentPointer >> 8) + (((UInt64)patchReader.ReadByte())<<56);
						current++;
					}
				}
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Parameters
			if (args.Length < 4)
			{
				Console.WriteLine("Usage: PatchPointersAuto originalGOs_prefix new_pointers_file patchedGOs_prefix RIO_file [RIO_length_to_update]");
				return;
			}

			string originalPrefix = args[0];
			string pointersFile = args[1];
			string patchedPrefix = args[2];
			string rioFileName = args[3];
			int rioLengthToUpdate = 0;
			if (args.Length <= 5)
				rioLengthToUpdate = Int32.Parse(args[4], System.Globalization.NumberStyles.Integer);
			#endregion

			#region Make pointers table
			Console.WriteLine("Preparing pointers map and reading headers from RIO file...");

			System.Collections.Hashtable pointers = new System.Collections.Hashtable();
			using (FileStream rioStream = new FileStream(rioFileName, FileMode.Open, FileAccess.Read))
			using (BinaryReader rioReader = new BinaryReader(rioStream))
			using (StreamReader pointersReader = new StreamReader(pointersFile))
			{
				string pointerStr;
				while ((pointerStr = pointersReader.ReadLine()) != null)
				{
					string[] pointerMap = pointerStr.Split(new char[]{' ', '\t'}, 2);
					UInt32 oldOffset = UInt32.Parse(pointerMap[0], System.Globalization.NumberStyles.Integer);
					UInt32 newOffset = UInt32.Parse(pointerMap[1], System.Globalization.NumberStyles.Integer);

					string newFileName = String.Format("{0}{1:d10}", patchedPrefix, oldOffset);
					UInt32 newSize = (UInt32)new FileInfo(newFileName).Length;

					string oldFileName = String.Format("{0}{1:d10}", originalPrefix, oldOffset);
					UInt32 oldSize = (UInt32)new FileInfo(oldFileName).Length;

					UInt64 oldPointer = (((UInt64)RIO.General.EncodeGOFileSize(oldSize))<<32) + 
						RIO.General.EncodeGOOffset(oldOffset-12);

					Pointer newPointer;
					newPointer.pointer = (((UInt64)RIO.General.EncodeGOFileSize(newSize))<<32) +
						RIO.General.EncodeGOOffset(newOffset-12);
					newPointer.headerOffset = (int)newOffset-12;
					newPointer.currentFileName = newFileName;
					newPointer.newFileName = String.Format("{0}{1:d10}", patchedPrefix, newOffset);

					rioStream.Position = oldOffset-12;
					newPointer.header = rioReader.ReadBytes(12);

					pointers.Add(oldPointer, newPointer);
				}
			}
			#endregion

			#region Patching pointers
			string[] patchedFiles = Directory.GetFiles(patchedPrefix, "*.");
			foreach (string file in patchedFiles)
			{
				Console.WriteLine("Patching pointers in file \"{0}\"...", file);
				PatchFile(file, pointers, 0);
			}
			Console.WriteLine("Patching pointers in file \"{0}\"...", rioFileName);
			PatchFile(rioFileName, pointers, rioLengthToUpdate);
			#endregion

			#region Patching RIO headers
			Console.WriteLine("Writing headers to new locations in RIO file...");
			using (FileStream rioStream = new FileStream(rioFileName, FileMode.Open, FileAccess.Write))
			using (BinaryWriter rioWriter = new BinaryWriter(rioStream))
			{
				foreach (Pointer pointer in pointers.Values)
				{
					rioWriter.Seek(pointer.headerOffset, SeekOrigin.Begin);
					rioWriter.Write(pointer.header);
				}
			}
			#endregion

			#region Renaming GOs
			Console.WriteLine("Renaming modified game object files...");
			foreach (Pointer pointer in pointers.Values)
			{
				File.Move(pointer.currentFileName, pointer.newFileName);
			}
			#endregion
		}
	}
}
