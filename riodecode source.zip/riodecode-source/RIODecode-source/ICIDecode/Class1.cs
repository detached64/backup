using System;
using System.IO;

namespace ICIDecode
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Reading arguments
			if (args.Length < 2)
			{
				Console.Out.WriteLine("Usage: ICIDecode source destination");
				return;
			}

			string sourceFileName = args[0];
			string destinationFileName = args[1];
			#endregion

			using (FileStream inputStream = new FileStream(sourceFileName, FileMode.Open, FileAccess.Read))
			using (BinaryReader inputReader = new BinaryReader(inputStream))
			using (FileStream outputStream = new FileStream(destinationFileName, FileMode.Create, FileAccess.Write))
			using (BinaryWriter outputWriter = new BinaryWriter(outputStream))
			{
				UInt32 size = inputReader.ReadUInt32();
				UInt32 size2 = inputReader.ReadUInt32();

				if (size != size2)
					throw new DecodeFailedException();

				byte[] source = inputReader.ReadBytes((int)size);
				byte[] dest1 = new byte[size];

				#region Mix by 6
				UInt32 offsetDest = 0;
				UInt32 counter = size/6;

				for (int offsetSrc=0; offsetSrc<counter; offsetSrc++)
				{
					dest1[offsetDest] = source[offsetSrc];
					dest1[offsetDest+1] = source[offsetSrc+counter];
					dest1[offsetDest+2] = source[offsetSrc+counter*2];
					dest1[offsetDest+3] = source[offsetSrc+counter*3];
					dest1[offsetDest+4] = source[offsetSrc+counter*4];
					dest1[offsetDest+5] = source[offsetSrc+counter*5];
					offsetDest+=6;
				}
				while(offsetDest<size)
				{
					dest1[offsetDest] = source[offsetDest];
					offsetDest++;
				}
				#endregion

				#region Diff with XOR
				byte prev = 0;
				for (int i=0; i<size; i++)
				{
					byte svPrev = prev;
					prev = dest1[i];
					dest1[i] = (byte)((dest1[i]-svPrev) ^ 0xA5);
				}
				#endregion

				#region Mix by 5
				counter = size/5;
				offsetDest = 0;
				byte[] dest2 = new byte[size];

				for (int offsetSrc = 0; offsetSrc < counter; offsetSrc++)
				{
					dest2[offsetDest] = dest1[offsetSrc];
					dest2[offsetDest+1] = dest1[offsetSrc+counter];
					dest2[offsetDest+2] = dest1[offsetSrc+counter*2];
					dest2[offsetDest+3] = dest1[offsetSrc+counter*3];
					dest2[offsetDest+4] = dest1[offsetSrc+counter*4];
					offsetDest+=5;
				}

				while(offsetDest<size)
				{
					dest2[offsetDest] = dest1[offsetDest];
					offsetDest++;
				}
				#endregion

				#region Simple diff
				prev = 0;
				for (int i = (int)size-1; i >= 0; i--)
				{
					byte svPrev = prev;
					prev = dest2[i];
					dest2[i] = (byte)(dest2[i]-svPrev);
				}
				#endregion

				#region Mix by 3 with XOR
				counter = size/3;
				offsetDest = 0;
				byte[] dest3 = new byte[size];

				for (int offsetSrc = 0; offsetSrc < counter; offsetSrc++)
				{
					dest3[offsetDest] = (byte)(dest2[offsetSrc] ^ 0x18);
					dest3[offsetDest+1] = (byte)(dest2[offsetSrc+counter] ^ 0x3F);
					dest3[offsetDest+2] = (byte)(dest2[offsetSrc+counter*2] ^ 0xE2);
					offsetDest+=3;
				}
				while(offsetDest<size)
				{
					dest3[offsetDest] = dest2[offsetDest];
					offsetDest++;
				}
				#endregion

				outputWriter.Write(dest3);
			}
		}
	}

	class DecodeFailedException: Exception
	{
	}
	}
