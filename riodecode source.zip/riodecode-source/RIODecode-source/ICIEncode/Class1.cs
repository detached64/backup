using System;
using System.IO;

namespace ICIEncode
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Reading arguments
			if (args.Length < 2)
			{
				Console.Out.WriteLine("Usage: ICIEncode source destination");
				return;
			}

			string sourceFileName = args[0];
			string destinationFileName = args[1];
			#endregion

			using (FileStream inputStream = new FileStream(sourceFileName, FileMode.Open, FileAccess.Read))
			using (BinaryReader inputReader = new BinaryReader(inputStream))
			using (FileStream outputStream = new FileStream(destinationFileName, FileMode.Create, FileAccess.Write))
			using (BinaryWriter outputWriter = new BinaryWriter(outputStream))
			{
				int size = (int)inputStream.Length;

				byte[] dest3 = inputReader.ReadBytes(size);

				#region Mix by 3 with XOR
				int counter = size/3;
				int offsetSrc = 0;
				byte[] dest2 = new byte[size];

				for (int offsetDest = 0; offsetDest < counter; offsetDest++)
				{
					dest2[offsetDest] = (byte)(dest3[offsetSrc] ^ 0x18);
					dest2[offsetDest+counter] = (byte)(dest3[offsetSrc+1] ^ 0x3F);
					dest2[offsetDest+counter*2] = (byte)(dest3[offsetSrc+2] ^ 0xE2);
					offsetSrc+=3;
				}
				while (offsetSrc < size)
				{
					dest2[offsetSrc] = dest3[offsetSrc];
					offsetSrc++;
				}
				#endregion

				#region Simple diff
				byte prev = 0;
				for (int i = size-1; i>=0; i--)
				{
					dest2[i] = (byte)(dest2[i]+prev);
					prev = dest2[i];
				}
				#endregion

				#region Mix by 5
				counter = size/5;
				offsetSrc = 0;
				byte[] dest1 = new byte[size];
				for (int offsetDest = 0; offsetDest < counter; offsetDest++)
				{
					dest1[offsetDest] = dest2[offsetSrc];
					dest1[offsetDest+counter] = dest2[offsetSrc+1];
					dest1[offsetDest+counter*2] = dest2[offsetSrc+2];
					dest1[offsetDest+counter*3] = dest2[offsetSrc+3];
					dest1[offsetDest+counter*4] = dest2[offsetSrc+4];
					offsetSrc += 5;
				}
				while (offsetSrc < size)
				{
					dest1[offsetSrc] = dest2[offsetSrc];
					offsetSrc++;
				}
				#endregion

				#region Diff with XOR
				prev = 0;
				for (int i=0; i<size; i++)
				{
					dest1[i] = (byte)((dest1[i]^0xA5)+prev);
					prev = dest1[i];
				}
				#endregion

				#region Mix by 6
				counter = size/6;
				offsetSrc = 0;
				byte[] encoded = new byte[size];
				for (int offsetDest = 0; offsetDest < counter; offsetDest++)
				{
					encoded[offsetDest] = dest1[offsetSrc];
					encoded[offsetDest+counter] = dest1[offsetSrc+1];
					encoded[offsetDest+counter*2] = dest1[offsetSrc+2];
					encoded[offsetDest+counter*3] = dest1[offsetSrc+3];
					encoded[offsetDest+counter*4] = dest1[offsetSrc+4];
					encoded[offsetDest+counter*5] = dest1[offsetSrc+5];
					offsetSrc += 6;
				}
				while (offsetSrc < size)
				{
					encoded[offsetSrc] = dest1[offsetSrc];
					offsetSrc++;
				}
				#endregion

				outputWriter.Write((UInt32)size);
				outputWriter.Write((UInt32)size);
				outputWriter.Write(encoded);
			}		
		}
	}
}
