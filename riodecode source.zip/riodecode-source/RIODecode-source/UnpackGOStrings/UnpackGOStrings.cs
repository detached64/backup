using System;
using System.IO;

namespace UnpackGOStrings
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Parameters
			if (args.Length < 2)
			{
				Console.WriteLine("Usage: UnpackGOStrings game_object text_file [max_number_gap_1=5 max_object_size_1=500 max_number_gap_2=50 passes=20 max_start=100 min_object_data=4]");
				return;
			}

			string inputFileName = args[0];
			string outputFileName = args[1];

			int maxNumberGap1 = 5;
			int maxObjectSize1 = 500;
			if (args.Length >= 3)
				maxNumberGap1 = int.Parse(args[2]);
			if (args.Length >= 4)
				maxObjectSize1 = int.Parse(args[3]);

			int maxNumberGap2 = 50;
			if (args.Length >= 5)
				maxNumberGap2 = int.Parse(args[4]);

			int passesCount = 20;
			if (args.Length >= 6)
				passesCount = int.Parse(args[5]);

			int maxStartNumber = 100;
			if (args.Length >= 7)
				maxStartNumber = int.Parse(args[6]);

			int minObjectLength = 4;
			if (args.Length >= 8)
				minObjectLength = int.Parse(args[7]);
			#endregion

			using (FileStream inputStream = new FileStream(inputFileName, FileMode.Open, FileAccess.Read))
			using (BinaryReader inputReader = new BinaryReader(inputStream, System.Text.Encoding.GetEncoding("shift-jis")))
			using (FileStream outputStream = new FileStream(outputFileName, FileMode.Create, FileAccess.Write))
			using (StreamWriter outputWriter = new StreamWriter(outputStream, System.Text.Encoding.GetEncoding("shift-jis")))
			{
				int inputLength = (int)inputStream.Length;
				byte[] input = inputReader.ReadBytes(inputLength);

				System.Collections.ArrayList endPoints = new System.Collections.ArrayList();
				System.Collections.Hashtable persistentGoodObjects = new System.Collections.Hashtable();

				int size = (int)input[0x14] + (((int)input[0x15])<<8) +
					(((int)input[0x16])<<16) + (((int)input[0x17])<<24);

				outputWriter.WriteLine("T " + Convert.ToString(size, 10));

				for (int pass=0; pass < passesCount; pass++)
				{
					Console.Write("Pass " + Convert.ToString(pass) + " endpoints: ");
					foreach(int i in endPoints)
					{
						if (persistentGoodObjects.Contains(i))
							Console.Write(Convert.ToString(persistentGoodObjects[i]) + "->");
						Console.Write(Convert.ToString(i)+" ");
					}
					Console.WriteLine();

					bool writeResult = (pass==passesCount-1);

					int curNumber = 0;
					int curOffset = 0;
					int lastSeen = 0;
					int lastObject = 0;
					int lastSize = 0;
					int lastEndPointsSize = endPoints.Count;
					bool lastWasString = false;
					string delayedLine = string.Empty;
					int delayedThreshold = 0;

					System.Collections.ArrayList allObjects = new System.Collections.ArrayList();

					for (int current = 0x18; current < inputLength-1; current++)
					{
						#region Try statement number
						if (current < inputLength-6 && current >= lastObject+minObjectLength)
						{
							int offset = (int)input[current] + (((int)input[current+1])<<8) +
								(((int)input[current+2])<<16) + (((int)input[current+3])<<24);
							int number = (int)input[current+4] + (((int)input[current+5])<<8);
							//UInt32 offset, then UInt16 number
							if ((offset & 0xfff00000) == 0 &&
								number < 6000 && number > 0 &&							
								offset > curOffset &&
								!allObjects.Contains(number))
							{
								bool isObject = false;
								if (curNumber == 0 && offset < maxObjectSize1)
								{
									if (number < maxStartNumber)
										isObject = true;
								}
								else if (offset-curOffset < maxObjectSize1)
								{
									if (Math.Abs(number - curNumber) < maxNumberGap1)
									{
										isObject = true;
									}
									else if (!persistentGoodObjects.ContainsKey(number) ||
										allObjects.Contains(persistentGoodObjects[number]))
									{
										foreach(int endPoint in endPoints)
										{
											if (Math.Abs(number-endPoint) < maxNumberGap2/* &&
												(!persistentGoodObjects.ContainsKey(endPoint) ||
												allObjects.Contains(persistentGoodObjects[endPoint]))*/)
											{
												isObject = true;
												break;
											}
										}

										if (isObject && !endPoints.Contains(curNumber))
											endPoints.Add(curNumber);
									}
								}

								if (isObject)
								{
									#region Try goto statement
									if (current >= lastSeen+9)
									{
										int opOffset = (int)input[current-6] + (((int)input[current-5])<<8) +
											(((int)input[current-4])<<16) + (((int)input[current-3])<<24);
										int opCode = (int)input[current-9] + (((int)input[current-8])<<8);

										if ((opOffset & 0xfff00000) == 0 &&
											//(opCode == 0x807B || opCode == 0x8008 || opCode == 0x801E))
											//(opCode & 0xff00) == 0x8000)
											(opCode >= 0x40 && opCode <= 0x47))
										{
											if (writeResult)
											{
												if (current-6 > delayedThreshold && delayedLine != string.Empty)
												{
													outputWriter.WriteLine(delayedLine);
												}
												delayedLine = string.Empty;
												outputWriter.WriteLine("G " +
													Convert.ToString(current-6, 10) + " " +
													Convert.ToString(opOffset, 10));
											}
										}
									}
									#endregion

									if (writeResult)
									{
										if (current > delayedThreshold && delayedLine != string.Empty)
										{
											outputWriter.WriteLine(delayedLine);
										}
										delayedLine = string.Empty;
										outputWriter.WriteLine("O " +
											Convert.ToString(number,10) + " " +
											Convert.ToString(current, 10) + " " +
											Convert.ToString(offset,10));
									}

									allObjects.Add(number);
									if (!persistentGoodObjects.ContainsKey(number))
									{
										persistentGoodObjects.Add(number, curNumber);
									}

									current += 5;
									lastSize = offset-curOffset;
									lastSeen = current+1;
									lastObject = lastSeen;
									curNumber = number;
									curOffset = offset;
									lastWasString = false;
									continue;
								}
							}
						}
						#endregion

						#region Try string
						int strLen;
						while ((strLen = input[current+1]) >= 4 &&
							current + strLen+3 < inputLength &&
							(strLen > 5 || input[current + strLen+1] == 1 || input[current] != 0) &&
							(
								(input[current + strLen+2] == 0 && input[current + strLen+3] == 0) ||
								(input[current + strLen+1] == 1) ||
								(current + strLen+3 + input[current + strLen+2] < inputLength && input[current+strLen+3+input[current+strLen+2]] == 0)
							)
							)
						{
							StreamReader strReader = new StreamReader(
								new MemoryStream(input, current+2, strLen),
								System.Text.Encoding.GetEncoding("shift-jis"));

							#region Replace special symbols
							string str = String.Empty;
							char[] ch = new char[strLen];
							int readStrLen = strReader.Read(ch, 0, strLen);
							bool containsNull = false;
							for (int i=0; i<readStrLen; i++)
							{
								switch (ch[i])
								{
									case '\x00':
										containsNull = true;
										break;

									case '\x01':
										str += "<break>";
										break;

									case '\x03':
										str += "<pause>";
										break;

									case '\x0a':
										str += "<linebreak>";
										break;

									case '\x0d':
										str += "<newline>";
										break;

									default:
										str += ch[i];
										break;
								}
							}
							#endregion
							if (containsNull)
								break;

							#region Verify that string is in shift-jis
							byte[] encodedString = null;
							// Verify that string is in shift-jis encoding by writing it to a stream and then reading it back
							using (MemoryStream memStream = new MemoryStream())
							using (StreamWriter memWriter = new StreamWriter(memStream, System.Text.Encoding.GetEncoding("shift-jis")))
							using (StreamReader memReader = new StreamReader(memStream, System.Text.Encoding.GetEncoding("shift-jis")))
							{
								memWriter.Write(str.Replace("<break>", "\x01")
									.Replace("<linebreak>", "\x0a")
									.Replace("<pause>", "\x03")
									.Replace("<newline>", "\x0d"));
								memWriter.Flush();
								memStream.Position = 0;
								encodedString = memStream.GetBuffer();
							}
							if (encodedString.Length < strLen)
								break;
							bool equal = true;
							for (int i=0; i<strLen; i++)
							{
								if (encodedString[i] != input[current+2+i])
								{
									equal = false;
									break;
								}
							}
							if (!equal)
								break;
							#endregion

							string type;
							if (input[current] == 0)
							{
								if (lastWasString && writeResult)
									Console.WriteLine("Two strings in one object at " + Convert.ToString(current+1));
								type = "S";
								lastWasString = true;
							}
							else
								type = "P";
							if (type == "P")
							{
								if (current > delayedThreshold && delayedLine != string.Empty)
								{
									if (writeResult)
									{
										outputWriter.WriteLine(delayedLine);
									}
									delayedLine = string.Empty;
								}
								if (delayedLine == string.Empty)
								{
									delayedLine = type + " " + Convert.ToString(current+1, 10) + " " + 
										Convert.ToString(strLen, 10) + " " + str;
									delayedThreshold = current + strLen+2;
								}
								current++;
							}
							else
							{
								if (writeResult)
								{
									if (current > delayedThreshold && delayedLine != string.Empty)
									{
										outputWriter.WriteLine(delayedLine);
									}
									delayedLine = string.Empty;
									outputWriter.WriteLine(type + " " + Convert.ToString(current+1, 10) + " " + 
										Convert.ToString(strLen, 10) + " " + str);
								}
								current += strLen+1;
							}
							lastSeen = current+1;
						}
						#endregion
					}

					if (curNumber != 0 && !endPoints.Contains(curNumber))
					{
						endPoints.Add(curNumber);
					}

					if (lastEndPointsSize == endPoints.Count && !writeResult)
						pass = passesCount-2;
				}
			}
		}
	}
}
