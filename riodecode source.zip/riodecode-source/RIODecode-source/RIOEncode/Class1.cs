using System;
using System.IO;

namespace RIOEncode
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void encodeChunk(BinaryReader inputReader, BinaryWriter outputWriter, UInt32 seed)
		{
			UInt32 size1 = (UInt32)inputReader.ReadInt32();
			UInt32 size = (UInt32)inputReader.ReadInt32();

			Console.WriteLine("Writing chunk of length {0:d10} at position {1:d10}",
				size,
				outputWriter.BaseStream.Position);

			outputWriter.Write(~(size1^0xC92E568B));
			outputWriter.Write((size*8)^0xC92E568B);

			UInt32 activeSeed = seed;

			while (size > 0)
			{
				UInt16 chkSum = 0;
				UInt32 chunkLeft = size>0x20 ? 0x20 : size;
				size -= chunkLeft;

				// Decoding routine
				while(chunkLeft > 0)
				{
					byte b = inputReader.ReadByte();
					chkSum += (UInt16)(b*chunkLeft);
					b = (byte)(b ^ activeSeed);
					outputWriter.Write(b);
					activeSeed = ~((UInt32)((activeSeed >> 0xF)&1) + activeSeed*2 - 0x5C4C8937);
					chunkLeft--;
				}

				// File integrity check
				outputWriter.Write(chkSum);
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Parsing input parameters

			if (args.Length < 4)
			{
				Console.WriteLine("Usage: RIOEncode.exe source_file dest_file code start_offset\n" +
					"\tsource_file - file to be encoded and written into RIO file;\n" +
					"\tdest_file - RIO file to write into;\n" +
					"\tcode - hex number used to encode data;\n" +
					"\tstart_offset - offset in RIO file to start writing from.\n\n"+
					"Example: RIOEncode.exe Decoded\\0000168371 a017kds.rio 7e6b8ce2 0000168371");
				return;
			}

			string inputFileName = args[0];
			string outputFileName = args[1];
			UInt32 seed = UInt32.Parse(args[2],System.Globalization.NumberStyles.HexNumber);
			long start = (long)UInt64.Parse(args[3]);

			Console.WriteLine("Encoding file {0} to file {1} using code {2:x8} starting from {3:d10}\n",
				inputFileName,
				outputFileName,
				seed,
				start);

			#endregion

			using (FileStream inputStream = new FileStream(inputFileName, FileMode.Open, FileAccess.Read))
			using (BinaryReader inputReader = new BinaryReader(inputStream))
			using (FileStream outputStream = new FileStream(outputFileName, FileMode.Open, FileAccess.Write))
			using (BinaryWriter outputWriter = new BinaryWriter(outputStream))
			{
				outputStream.Position = start;
				encodeChunk(
					inputReader,
					outputWriter, seed);
			}
		}
	}
}
