using System;

namespace RIO
{
	/// <summary>
	/// Summary description for General.
	/// </summary>
	public class General
	{
		public static UInt32 EncodeGOFileSize(UInt32 fileSize)
		{
			UInt32 bigSize = 20 + (fileSize-8) + ((fileSize-8+31)/32)*2;

			UInt32 b = bigSize << 0xd;
			UInt32 a = bigSize & 0xfff;

			return a+b+0xe7b5d9f8;
		}

		public static UInt32 EncodeGOOffset(UInt32 offset)
		{
			return offset + 0xa2fb6ad1;
		}

		public General()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
