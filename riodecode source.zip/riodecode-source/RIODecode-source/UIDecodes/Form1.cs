using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace UIDecodes
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox sizeEncodedTextBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox sizeDecodedTextBox;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox offsetEncodedTextBox;
		private System.Windows.Forms.TextBox offsetDecodedTextBox;
		private System.Windows.Forms.Button decodeOffsetButton;
		private System.Windows.Forms.Button encodeOffsetButton;
		private System.Windows.Forms.Button decodeSizeButton;
		private System.Windows.Forms.Button encodeSizeButton;
		private System.Windows.Forms.TextBox decSizeEncodedTextBox;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button decSizeEncodeButton;
		private System.Windows.Forms.Button decSizeDecodeButton;
		private System.Windows.Forms.TextBox decSizeDecodedTextBox;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.sizeEncodedTextBox = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.sizeDecodedTextBox = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.offsetEncodedTextBox = new System.Windows.Forms.TextBox();
			this.offsetDecodedTextBox = new System.Windows.Forms.TextBox();
			this.decodeOffsetButton = new System.Windows.Forms.Button();
			this.encodeOffsetButton = new System.Windows.Forms.Button();
			this.decodeSizeButton = new System.Windows.Forms.Button();
			this.encodeSizeButton = new System.Windows.Forms.Button();
			this.decSizeEncodedTextBox = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.decSizeEncodeButton = new System.Windows.Forms.Button();
			this.decSizeDecodeButton = new System.Windows.Forms.Button();
			this.decSizeDecodedTextBox = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// sizeEncodedTextBox
			// 
			this.sizeEncodedTextBox.Location = new System.Drawing.Point(88, 8);
			this.sizeEncodedTextBox.Name = "sizeEncodedTextBox";
			this.sizeEncodedTextBox.TabIndex = 0;
			this.sizeEncodedTextBox.Text = "";
			this.sizeEncodedTextBox.TextChanged += new System.EventHandler(this.sizeEncodedTextBox_TextChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.TabIndex = 1;
			this.label1.Text = "Size:";
			// 
			// sizeDecodedTextBox
			// 
			this.sizeDecodedTextBox.Location = new System.Drawing.Point(288, 8);
			this.sizeDecodedTextBox.Name = "sizeDecodedTextBox";
			this.sizeDecodedTextBox.TabIndex = 2;
			this.sizeDecodedTextBox.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 32);
			this.label2.Name = "label2";
			this.label2.TabIndex = 3;
			this.label2.Text = "Offset:";
			// 
			// offsetEncodedTextBox
			// 
			this.offsetEncodedTextBox.Location = new System.Drawing.Point(88, 32);
			this.offsetEncodedTextBox.Name = "offsetEncodedTextBox";
			this.offsetEncodedTextBox.TabIndex = 4;
			this.offsetEncodedTextBox.Text = "";
			this.offsetEncodedTextBox.TextChanged += new System.EventHandler(this.offsetEncodedTextBox_TextChanged);
			// 
			// offsetDecodedTextBox
			// 
			this.offsetDecodedTextBox.Location = new System.Drawing.Point(288, 32);
			this.offsetDecodedTextBox.Name = "offsetDecodedTextBox";
			this.offsetDecodedTextBox.TabIndex = 6;
			this.offsetDecodedTextBox.Text = "";
			this.offsetDecodedTextBox.TextChanged += new System.EventHandler(this.offsetDecodedTextBox_TextChanged);
			// 
			// decodeOffsetButton
			// 
			this.decodeOffsetButton.Location = new System.Drawing.Point(192, 32);
			this.decodeOffsetButton.Name = "decodeOffsetButton";
			this.decodeOffsetButton.TabIndex = 5;
			this.decodeOffsetButton.Text = "Decode";
			this.decodeOffsetButton.Click += new System.EventHandler(this.decodeOffsetButton_Click);
			// 
			// encodeOffsetButton
			// 
			this.encodeOffsetButton.Location = new System.Drawing.Point(392, 32);
			this.encodeOffsetButton.Name = "encodeOffsetButton";
			this.encodeOffsetButton.TabIndex = 7;
			this.encodeOffsetButton.Text = "Encode";
			this.encodeOffsetButton.Click += new System.EventHandler(this.encodeOffsetButton_Click);
			// 
			// decodeSizeButton
			// 
			this.decodeSizeButton.Location = new System.Drawing.Point(192, 8);
			this.decodeSizeButton.Name = "decodeSizeButton";
			this.decodeSizeButton.TabIndex = 1;
			this.decodeSizeButton.Text = "Decode";
			this.decodeSizeButton.Click += new System.EventHandler(this.decodeSizeButton_Click);
			// 
			// encodeSizeButton
			// 
			this.encodeSizeButton.Location = new System.Drawing.Point(392, 8);
			this.encodeSizeButton.Name = "encodeSizeButton";
			this.encodeSizeButton.TabIndex = 3;
			this.encodeSizeButton.Text = "Encode";
			this.encodeSizeButton.Click += new System.EventHandler(this.encodeSizeButton_Click);
			// 
			// decSizeEncodedTextBox
			// 
			this.decSizeEncodedTextBox.Location = new System.Drawing.Point(88, 56);
			this.decSizeEncodedTextBox.Name = "decSizeEncodedTextBox";
			this.decSizeEncodedTextBox.TabIndex = 8;
			this.decSizeEncodedTextBox.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 56);
			this.label3.Name = "label3";
			this.label3.TabIndex = 11;
			this.label3.Text = "Size of decoded";
			// 
			// decSizeEncodeButton
			// 
			this.decSizeEncodeButton.Location = new System.Drawing.Point(392, 56);
			this.decSizeEncodeButton.Name = "decSizeEncodeButton";
			this.decSizeEncodeButton.TabIndex = 11;
			this.decSizeEncodeButton.Text = "Encode";
			this.decSizeEncodeButton.Click += new System.EventHandler(this.decSizeEncodeButton_Click);
			// 
			// decSizeDecodeButton
			// 
			this.decSizeDecodeButton.Location = new System.Drawing.Point(192, 56);
			this.decSizeDecodeButton.Name = "decSizeDecodeButton";
			this.decSizeDecodeButton.TabIndex = 9;
			this.decSizeDecodeButton.Text = "Decode";
			this.decSizeDecodeButton.Click += new System.EventHandler(this.decSizeDecodeButton_Click);
			// 
			// decSizeDecodedTextBox
			// 
			this.decSizeDecodedTextBox.Location = new System.Drawing.Point(288, 56);
			this.decSizeDecodedTextBox.Name = "decSizeDecodedTextBox";
			this.decSizeDecodedTextBox.TabIndex = 10;
			this.decSizeDecodedTextBox.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(480, 273);
			this.Controls.Add(this.decSizeEncodedTextBox);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.encodeSizeButton);
			this.Controls.Add(this.decodeSizeButton);
			this.Controls.Add(this.encodeOffsetButton);
			this.Controls.Add(this.decodeOffsetButton);
			this.Controls.Add(this.offsetDecodedTextBox);
			this.Controls.Add(this.offsetEncodedTextBox);
			this.Controls.Add(this.sizeDecodedTextBox);
			this.Controls.Add(this.sizeEncodedTextBox);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.decSizeEncodeButton);
			this.Controls.Add(this.decSizeDecodeButton);
			this.Controls.Add(this.decSizeDecodedTextBox);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void sizeEncodedTextBox_TextChanged(object sender, System.EventArgs e)
		{
		}

		private void offsetEncodedTextBox_TextChanged(object sender, System.EventArgs e)
		{
		}

		private void offsetDecodedTextBox_TextChanged(object sender, System.EventArgs e)
		{
		}

		private void decodeOffsetButton_Click(object sender, System.EventArgs e)
		{
			try
			{
				UInt32 sz = UInt32.Parse(offsetEncodedTextBox.Text, System.Globalization.NumberStyles.HexNumber);

				sz-=0xa2fb6ad1;

				offsetDecodedTextBox.Text = Convert.ToString(sz,10);
			}
			catch
			{
			}
		}

		private void encodeOffsetButton_Click(object sender, System.EventArgs e)
		{
			try
			{
				UInt32 sz = UInt32.Parse(offsetDecodedTextBox.Text);

				sz+=0xa2fb6ad1;

				offsetEncodedTextBox.Text = Convert.ToString(sz, 0x10);
			}
			catch
			{
			}
		}

		private void decodeSizeButton_Click(object sender, System.EventArgs e)
		{
			try
			{
				UInt32 sz = UInt32.Parse(sizeEncodedTextBox.Text, System.Globalization.NumberStyles.HexNumber);

				sz-=0xe7b5d9f8;				//9d5ceae
				UInt32 ecx = sz >> 0xd;		//4eae
				UInt32 edx = ecx & 0xfff;	//eae
				sz -= edx;					//9d5c000
				sz = sz << 0x13;			//0
				sz |= ecx;					//4eae

				sizeDecodedTextBox.Text = Convert.ToString(sz,10);
			}
			catch
			{
			}
		}

		private void encodeSizeButton_Click(object sender, System.EventArgs e)
		{
			try
			{
				UInt32 sz = UInt32.Parse(sizeDecodedTextBox.Text, System.Globalization.NumberStyles.Integer);
							//4eae

				UInt32 b = sz << 0xd;		//9d5c000
				UInt32 a = sz & 0xfff;

				sizeEncodedTextBox.Text = Convert.ToString(a+b+0xe7b5d9f8, 0x10);
			}
			catch
			{
			}
		}

		private void decSizeDecodeButton_Click(object sender, System.EventArgs e)
		{
			try
			{
				UInt32 encLen = UInt32.Parse(decSizeEncodedTextBox.Text, System.Globalization.NumberStyles.Integer);

				decSizeDecodedTextBox.Text = Convert.ToString(8+(encLen-20)-((encLen-20+33)/34)*2);
			}
			catch
			{
			}
		}

		private void decSizeEncodeButton_Click(object sender, System.EventArgs e)
		{
			try
			{
				UInt32 decLen = UInt32.Parse(decSizeDecodedTextBox.Text, System.Globalization.NumberStyles.Integer);
				decSizeEncodedTextBox.Text = Convert.ToString(20 + (decLen-8) + ((decLen-8+31)/32)*2);
			}
			catch
			{
			}
		}
	}
}
