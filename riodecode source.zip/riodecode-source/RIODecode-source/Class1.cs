using System;
using System.IO;

namespace RIODecode
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void decodeChunk(BinaryReader inputReader, string outputFileName, UInt32 seed, long maxChunkSize)
		{
			long initialPosition = inputReader.BaseStream.Position;
			if (initialPosition > inputReader.BaseStream.Length - 8)
			{
				inputReader.BaseStream.Position = inputReader.BaseStream.Length;
				return;
			}

			UInt32 size1 = ~((UInt32)inputReader.ReadInt32()^0xC92E568B);
			UInt32 size = ((UInt32)inputReader.ReadInt32()^0xC92E568F) >> 3;

			if (size1 != size)
			{
				inputReader.BaseStream.Position = initialPosition + 1;
				return;
			}

			try
			{
				using (FileStream outputStream = new FileStream(outputFileName, FileMode.Create, FileAccess.Write))
				using (BinaryWriter outputWriter = new BinaryWriter(outputStream))
				{
					outputWriter.Write(size1);
					outputWriter.Write(size);

					Console.WriteLine("Found chunk of length {0:d10} at position {1:d10}", size, initialPosition);

					if (maxChunkSize > 0 && size > maxChunkSize)
					{
						Console.WriteLine("\tChunk is bigger than {0:d10}, not decoding", maxChunkSize);
						throw new DecodeFailedException();
					}

					UInt32 activeSeed = seed;

					while (size > 0)
					{
						UInt16 chkSum = 0;
						UInt32 chunkLeft = size>0x20 ? 0x20 : size;
						size -= chunkLeft;

						// Decoding routine
						while(chunkLeft > 0)
						{
							byte b = (byte)(inputReader.ReadByte() ^ activeSeed);
							outputWriter.Write(b);
							chkSum += (UInt16)(b*chunkLeft);
							activeSeed = ~((UInt32)((activeSeed >> 0xF)&1) + activeSeed*2 - 0x5C4C8937);
							chunkLeft--;
						}

						// File integrity check
						UInt16 chkSumRead = inputReader.ReadUInt16();
						if (chkSum != chkSumRead)
							throw new DecodeFailedException();
					}
				}
			}
			catch (DecodeFailedException)
			{
				Console.WriteLine("\tDecode failed at position {0:d10}", inputReader.BaseStream.Position);
				File.Delete(outputFileName);
				inputReader.BaseStream.Position = initialPosition + 1;
			}
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Parsing input parameters

			if (args.Length < 3)
			{
				Console.WriteLine("Usage: RIODecode.exe source_file dest_prefix code [start_offset end_offset max_chunk_size]\n" +
					"\tsource_file - RIO file to decode;\n" +
					"\tdest_prefix - prefix to be used for decoded chunks;\n" +
					"\tcode - hex number used to encode data;\n" +
					"\tstart_offset - offset in RIO file to start decoding from;\n" +
					"\tend_offset - offset in RIO file to finish decoding on;\n" +
					"\tmax_chunk_size - Maximum size of chunk to be decoded\n" +
					"Example: RIODecode.exe A017KDS.rio Decoded\\ 7e6b8ce2 0 8000000");
				return;
			}

			string inputFileName = args[0];
			string outputPath = args[1];
			UInt32 seed = UInt32.Parse(args[2],System.Globalization.NumberStyles.HexNumber);
			long start = (long)(args.Length>=4 ? UInt64.Parse(args[3],System.Globalization.NumberStyles.Integer) : 0);
			long end = (long)(args.Length>=5 ? UInt64.Parse(args[4],System.Globalization.NumberStyles.Integer) : 0);
			long maxChunkSize = (long)(args.Length>=6 ? UInt64.Parse(args[5],System.Globalization.NumberStyles.Integer) : 0);

			Console.WriteLine("Decoding file {0} to path {1} using code {2:x8} starting from {3:d10} finishing on {4:d10} saving chunks of at most {5:d10}\n",
				inputFileName,
				outputPath,
				seed,
				start,
				end,
				maxChunkSize);

			#endregion

			using (FileStream inputStream = new FileStream(inputFileName, FileMode.Open, FileAccess.Read))
			using (BinaryReader inputReader = new BinaryReader(inputStream))
			{
				inputStream.Position = start;
				while (inputStream.Position < inputStream.Length && 
					(end <= 0 || inputStream.Position < end))
				{
					if ((inputStream.Position & 0xffff) == 0)
						Console.WriteLine("Position: {0:d10}/{1:d10}",inputStream.Position, inputStream.Length);
					decodeChunk(
						inputReader,
						string.Format("{0}{1:d10}", outputPath, inputStream.Position),
						seed,
						maxChunkSize);
				}
			}
		}
	}

	class DecodeFailedException: Exception
	{
	}
}
