using System;
using System.IO;

namespace PatchGOStrings
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			#region Parameters
			if (args.Length < 3)
			{
				Console.WriteLine("Usage: UnpackGOStrings original_game_object text_file target_game_object [additional_memory=0]");
				return;
			}

			string inputFileName = args[0];
			string patchFileName = args[1];
			string outputFileName = args[2];
			int additionalMemory = 0;
			if (args.Length >= 4)
				additionalMemory = int.Parse(args[3]);
			#endregion

			using (FileStream inputStream = new FileStream(inputFileName, FileMode.Open, FileAccess.Read))
			using (BinaryReader inputReader = new BinaryReader(inputStream))
			using (FileStream patchStream = new FileStream(patchFileName, FileMode.Open, FileAccess.Read))
			using (StreamReader patchReader = new StreamReader(patchStream, System.Text.Encoding.GetEncoding("shift-jis")))
			using (FileStream outputStream = new FileStream(outputFileName, FileMode.Create, FileAccess.Write))
			using (BinaryWriter outputWriter = new BinaryWriter(outputStream, System.Text.Encoding.GetEncoding("shift-jis")))
			{
				System.Collections.Hashtable statements = new System.Collections.Hashtable();
				System.Collections.Hashtable gotoStatements = new System.Collections.Hashtable();
				int objectOffset = 0;
				int objectNextOffset = 0;
				int memoryOffsetCorrection = 0;
				int fileOffsetCorrection = 0;
				int totalSize = 0;

				while (true)
				{
					string patchStr = patchReader.ReadLine();
					if (patchStr == null || patchStr == String.Empty)
						break;

					char lineType = patchStr[0];
					patchStr = patchStr.Remove(0, 1).TrimStart(' ');
					string[] patchSplit;

					switch (lineType)
					{
						case 'T':
							#region Patch object size
							totalSize += Int32.Parse(patchStr, System.Globalization.NumberStyles.Integer);
							break;
							#endregion

						case 'P':
						case 'S':
							#region Patch string
							patchSplit = patchStr.Split(new char[]{' '}, 3);
					
							int originalOffset = Int32.Parse(patchSplit[0], System.Globalization.NumberStyles.Integer);
							int originalLength = Int32.Parse(patchSplit[1], System.Globalization.NumberStyles.Integer);
							string newStr = patchSplit[2];

							newStr = newStr.Replace("<break>", "\x01")
								.Replace("<linebreak>", "\x0a")
								.Replace("<pause>", "\x03")
								.Replace("<newline>", "\x0d");

							if (inputStream.Position < originalOffset)
								outputWriter.Write(inputReader.ReadBytes(originalOffset - (int)inputStream.Position));

							inputStream.Seek(originalLength+1, SeekOrigin.Current);

							using (MemoryStream strStream = new MemoryStream())
							using (StreamWriter strWriter = new StreamWriter(strStream, System.Text.Encoding.GetEncoding("shift-jis")))
							using (BinaryReader strReader = new BinaryReader(strStream, System.Text.Encoding.GetEncoding("shift-jis")))
							{

								foreach (char c in newStr)
								{
									strWriter.Write(c);
									strWriter.Flush();
									if (strStream.Length > 200)
									{
										Console.WriteLine("String at offset " + originalOffset + " exceeds 200 characters and has been cut.");
										// Make sure that strings don't become longer than 255 characters
										break;
									}
								}

								while (strStream.Length < originalLength ||
									((strStream.Length - originalLength) & 0x3) != 0)
								{
									strWriter.Write(' ');
									strWriter.Flush();
								}

								if (lineType == 'S')
									memoryOffsetCorrection += (int)strStream.Length - originalLength;
								fileOffsetCorrection += (int)strStream.Length - originalLength;

								outputWriter.Write((byte)strStream.Length);
								strStream.Position = 0;
								byte[] buf = strReader.ReadBytes((int)strStream.Length);
								outputWriter.Write(buf);
							}
							break;
							#endregion

						case 'O':
							#region Patch object
							if (objectOffset != 0)
							{
								statements.Add(objectNextOffset, objectNextOffset+memoryOffsetCorrection);

								outputWriter.Seek(objectOffset, SeekOrigin.Begin);
								outputWriter.Write(objectNextOffset+memoryOffsetCorrection);
								outputWriter.Seek(0, SeekOrigin.End);
							}

							patchSplit = patchStr.Split(new char[]{' '}, 3);
							objectOffset = Int32.Parse(patchSplit[1], System.Globalization.NumberStyles.Integer);
							objectNextOffset = Int32.Parse(patchSplit[2], System.Globalization.NumberStyles.Integer);

							if (inputStream.Position < objectOffset+6)
								outputWriter.Write(inputReader.ReadBytes(objectOffset+6 - (int)inputStream.Position));

							objectOffset += fileOffsetCorrection;
							break;
							#endregion

						case 'G':
							#region goto statement
							patchSplit = patchStr.Split(new char[]{' '}, 2);
							int gotoStatementOffset = int.Parse(patchSplit[0]);
							int gotoDestOffset = int.Parse(patchSplit[1]);
							gotoStatements.Add(gotoStatementOffset+fileOffsetCorrection, gotoDestOffset);
							break;
							#endregion
					}
				}

				if (inputStream.Position < inputStream.Length)
					outputWriter.Write(inputReader.ReadBytes((int)inputStream.Length - (int)inputStream.Position));

				if (objectOffset != 0)
				{
					outputWriter.Seek(objectOffset, SeekOrigin.Begin);
					outputWriter.Write(objectNextOffset + memoryOffsetCorrection + additionalMemory);
					outputWriter.Seek(0, SeekOrigin.End);
				}

				if (totalSize != 0)
				{
					outputWriter.Seek(0x14, SeekOrigin.Begin);
					outputWriter.Write(totalSize + fileOffsetCorrection);
				}

				foreach(int gotoStatementOffset in gotoStatements.Keys)
				{
					outputWriter.Seek(gotoStatementOffset, SeekOrigin.Begin);
					int gotoDest = (int)gotoStatements[gotoStatementOffset];
					if (statements.ContainsKey(gotoDest))
					{
						Console.WriteLine("Updated goto at " + Convert.ToString(gotoStatementOffset) +
							" to " + gotoDest);
						outputWriter.Write((int)statements[gotoDest]);
					}
				}

				outputWriter.Flush();
				outputStream.Flush();

				outputStream.Position = 0;
				outputWriter.Write((UInt32)outputStream.Length-8);
				outputWriter.Write((UInt32)outputStream.Length-8);
			}
		}
	}
}
