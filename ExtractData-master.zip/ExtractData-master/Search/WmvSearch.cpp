#include "StdAfx.h"
#include "Search/WmvSearch.h"

#include "ArcFile.h"
#include "Common.h"
#include "UI/ProgressBar.h"

CWmvSearch::CWmvSearch()
{
	InitHeader("\x30\x26\xB2\x75\x8E\x66\xCF\x11\xA6\xD9\x00\xAA\x00\x62\xCE\x6C", 16);
	InitFooter("\xA1\xDC\xAB\x8C\x47\xA9\xCF\x11\x8E\xE4\x00\xC0\x0C\x20\x53\x65\x68", 17);
}

void CWmvSearch::Mount(CArcFile* archive)
{
	SFileInfo file_info;

	// Get start address
	file_info.start = archive->GetArcPointer();
	archive->Seek(GetHeaderSize(), FILE_CURRENT);

	// Search the auxiliary header
	if (!SearchFooter(archive))
		return;

	// Amount of progress advanced by the search bar
	const u64 search_offset = archive->GetArcPointer() - file_info.start - GetHeaderSize();

	// Get file size
	archive->Seek(23, FILE_CURRENT);
	archive->Read(&file_info.size_org, 4);
	file_info.size_cmp = file_info.size_org;

	// Get exit address
	file_info.end = file_info.start + file_info.size_org;

	// Go to the end of the WMV file
	archive->Seek(file_info.end, FILE_BEGIN);
	archive->GetProg()->UpdatePercent(file_info.size_org - search_offset);

	archive->AddFileInfo(file_info, GetNumFiles(), _T(".wmv"));
}
